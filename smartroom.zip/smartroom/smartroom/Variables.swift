//
//  Variables.swift
//  smartroom
//
//  Created by Bruno Luis Mendivez Vasquez on 14/11/2016.
//  Copyright © 2016 Bruno Luis Mendivez Vasquez. All rights reserved.
//

import Foundation

struct MyVariables {
    static var SERVER_IP_ADDRESS: String = "118.139.51.83"
}
