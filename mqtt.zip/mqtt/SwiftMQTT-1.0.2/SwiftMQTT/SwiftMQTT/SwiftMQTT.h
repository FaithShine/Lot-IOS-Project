//
//  SwiftMQTT.h
//  SwiftMQTT
//
//  Created by Ankit Aggarwal on 10/11/15.
//  Copyright © 2015 Ankit. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftMQTT.
FOUNDATION_EXPORT double SwiftMQTTVersionNumber;

//! Project version string for SwiftMQTT.
FOUNDATION_EXPORT const unsigned char SwiftMQTTVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftMQTT/PublicHeader.h>


